void main() {
  // Generate and print the first 10 numbers in the Fibonacci sequence
  for (int i = 0; i < 10; i++) {
    print(fibonacci(i));
  }
}

int fibonacci(int n) {
  // The first two numbers in the sequence are 0 and 1
  if (n == 0 || n == 1) {
    return n;
  }

  // The nth number in the sequence is the sum of the (n - 1)th and (n - 2)th numbers
  return fibonacci(n - 1) + fibonacci(n - 2);
}

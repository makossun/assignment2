import 'dart:io';

void main(List<String> args) {
  var base = double.parse(stdin.readLineSync()!);
  // read the newline character left in the buffer
  stdin.readLineSync();
  var height = double.parse(stdin.readLineSync()!);
  print(0.5 * base * height);
}
